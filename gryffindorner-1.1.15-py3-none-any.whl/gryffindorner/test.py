# -*- coding: utf-8 -*-
"""
Created on Mon Apr 11 21:13:14 2022

@author: alexl_g8yj9pc
"""

from getNER import getNER

example = "First National Credit Union issues the Super Awesome Rewards Card with an introductory APR of 15.00%. Wisconsin residents note that there are special rules."

ents, rels = getNER(example, 0.05)